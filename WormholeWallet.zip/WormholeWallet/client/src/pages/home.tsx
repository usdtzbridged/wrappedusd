import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import TokenOverview from "@/components/token-overview";
import SupportedChains from "@/components/supported-chains";
import HowItWorks from "@/components/how-it-works";
import BridgeInterface from "@/components/bridge-interface";
import SecurityFeatures from "@/components/security-features";
import TeamSection from "@/components/team-section";
import Documentation from "@/components/documentation";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-neutral">
      <Navigation />
      <HeroSection />
      <TokenOverview />
      <SupportedChains />
      <HowItWorks />
      <BridgeInterface />
      <SecurityFeatures />
      <TeamSection />
      <Documentation />
      <Footer />
    </div>
  );
}
