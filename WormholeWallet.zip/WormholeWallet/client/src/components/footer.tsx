import { Twitter, MessageCircle, Github, Send } from "lucide-react";

export default function Footer() {
  const footerLinks = {
    product: [
      { name: "Bridge", href: "#bridge" },
      { name: "Supported Chains", href: "#chains" },
      { name: "Token Info", href: "#overview" },
      { name: "Security", href: "#security" }
    ],
    resources: [
      { name: "Documentation", href: "#docs" },
      { name: "API Reference", href: "#" },
      { name: "Tutorials", href: "#" },
      { name: "FAQ", href: "#" }
    ],
    company: [
      { name: "About", href: "#" },
      { name: "Terms", href: "#" },
      { name: "Privacy", href: "#" },
      { name: "Contact", href: "#" }
    ]
  };

  const socialLinks = [
    { icon: Twitter, href: "https://x.com/wrappedwusdt", label: "Twitter" },
    { icon: Send, href: "https://t.me/wrappedusdt", label: "Telegram" },
    { icon: Github, href: "https://github.com/wrappedusdtt", label: "GitHub" },
    { icon: MessageCircle, href: "https://medium.com/@wrappedusdt", label: "Medium" }
  ];

  const scrollToSection = (sectionId: string) => {
    if (sectionId.startsWith('#')) {
      const element = document.getElementById(sectionId.substring(1));
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <footer className="bg-darkgray text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
                <i className="fas fa-exchange-alt text-white text-lg"></i>
              </div>
              <span className="font-bold text-xl">wUSDT</span>
            </div>
            <p className="text-gray-400 mb-4">
              Wrapped Tether (wUSDT) is a tokenized version of Tether (USD₮) on the Solana blockchain.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className="text-gray-400 hover:text-white transition-colors"
                  aria-label={social.label}
                >
                  <social.icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold text-lg mb-4">Product</h4>
            <ul className="space-y-2 text-gray-400">
              {footerLinks.product.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => scrollToSection(link.href)}
                    className="hover:text-white transition-colors text-left"
                  >
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-lg mb-4">Resources</h4>
            <ul className="space-y-2 text-gray-400">
              {footerLinks.resources.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => scrollToSection(link.href)}
                    className="hover:text-white transition-colors text-left"
                  >
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-lg mb-4">Company</h4>
            <ul className="space-y-2 text-gray-400">
              {footerLinks.company.map((link, index) => (
                <li key={index}>
                  <a href={link.href} className="hover:text-white transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-600 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2024 Wrapped USDT (wUSDT). All rights reserved.</p>
          <p className="mt-2 text-sm">
            This tokenized version is not issued by, redeemable by, or affiliated with Tether. 
            Tether is not responsible for it.
          </p>
        </div>
      </div>
    </footer>
  );
}
