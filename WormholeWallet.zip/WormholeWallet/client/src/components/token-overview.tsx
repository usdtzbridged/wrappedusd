import { Network, Zap, Shield, Clock, Users, Lock } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function TokenOverview() {
  const { data: tokenData } = useQuery({
    queryKey: ['/api/token'],
  });

  const features = [
    {
      icon: Network,
      title: "Solana Native",
      description: "Built on Solana blockchain",
      gradient: "from-blue-50 to-indigo-100",
      color: "text-primary"
    },
    {
      icon: Users,
      title: `${tokenData?.holders || 121} Holders`,
      description: "Growing community",
      gradient: "from-green-50 to-emerald-100",
      color: "text-secondary"
    },
    {
      icon: Lock,
      title: "2B Locked",
      description: "20% of supply locked",
      gradient: "from-purple-50 to-violet-100",
      color: "text-accent"
    },
    {
      icon: Shield,
      title: "Verified",
      description: "Fully audited and secure",
      gradient: "from-orange-50 to-amber-100",
      color: "text-orange-600"
    }
  ];

  return (
    <section id="overview" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-darkgray mb-4">Token Overview</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Wrapped Tether (wUSDT) is a tokenized version of Tether (USD₮) on the Solana blockchain. 
            Total supply: 10B | Circulating: 9.99B | Locked: 2B tokens
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div key={index} className={`bg-gradient-to-br ${feature.gradient} p-6 rounded-xl hover:shadow-lg transition-shadow`}>
              <feature.icon className={`h-8 w-8 ${feature.color} mb-4`} />
              <div className="text-2xl font-bold text-darkgray mb-2">{feature.title}</div>
              <div className="text-gray-600">{feature.description}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
