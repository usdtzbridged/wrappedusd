import { Lock, ArrowLeftRight, Coins } from "lucide-react";

export default function HowItWorks() {
  const steps = [
    {
      icon: Lock,
      title: "1. Lock Tokens",
      description: "Your USDT tokens are locked in a smart contract on the source blockchain network.",
      gradient: "from-primary to-accent"
    },
    {
      icon: ArrowLeftRight,
      title: "2. Cross-Chain Transfer",
      description: "Wormhole's Guardian network validates the transaction and facilitates the cross-chain transfer.",
      gradient: "from-secondary to-green-400"
    },
    {
      icon: Coins,
      title: "3. Mint on Destination",
      description: "Wrapped USDT tokens are minted on the destination chain, representing your locked tokens.",
      gradient: "from-accent to-purple-400"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-darkgray mb-4">How It Works</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Wormhole follows a 'lock and mint' mechanism to perform secure cross-chain transactions.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="text-center">
              <div className={`w-16 h-16 bg-gradient-to-r ${step.gradient} rounded-full flex items-center justify-center mx-auto mb-6`}>
                <step.icon className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-darkgray mb-4">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
