import { Button } from "@/components/ui/button";
import { ArrowRight, BookOpen, ArrowLeftRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const { data: priceData, isLoading } = useQuery({
    queryKey: ['/api/token/price'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: tokenData } = useQuery({
    queryKey: ['/api/token'],
  });

  const formatPrice = (price: string | number) => {
    const numPrice = typeof price === 'string' ? parseFloat(price) : price;
    return numPrice ? `$${numPrice.toFixed(4)}` : '$0.0000';
  };

  const formatChange = (change: string | number) => {
    const numChange = typeof change === 'string' ? parseFloat(change) : change;
    return numChange ? `${numChange > 0 ? '+' : ''}${numChange.toFixed(2)}%` : '0.00%';
  };

  return (
    <section className="pt-24 pb-16 bg-gradient-hero">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-darkgray mb-6">
            Wrapped USDT
            <span className="text-primary block">Solana Token</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Wrapped Tether (wUSDT) is a tokenized version of Tether (USD₮) on the Solana blockchain. 
            Trade, hold, and transfer wUSDT tokens with industry-leading security and verification.
          </p>
          
          {/* Price Display */}
          <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-8 mb-8">
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <div className="text-3xl font-bold text-darkgray">
                {isLoading ? 'Loading...' : formatPrice(priceData?.price || '0.1273')}
              </div>
              <div className="text-sm text-gray-500">Current Price</div>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-lg">
              <div className={`text-3xl font-bold ${
                priceData?.change24h && parseFloat(priceData.change24h) >= 0 ? 'text-secondary' : 'text-red-600'
              }`}>
                {isLoading ? 'Loading...' : formatChange(priceData?.change24h || '62.87')}
              </div>
              <div className="text-sm text-gray-500">24h Change</div>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Button 
              onClick={() => scrollToSection('bridge')}
              className="bg-primary hover:bg-blue-700 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-colors w-full sm:w-auto"
            >
              <ArrowLeftRight className="mr-2 h-5 w-5" />
              Start Bridge Transfer
            </Button>
            <Button 
              onClick={() => scrollToSection('docs')}
              variant="outline"
              className="bg-white hover:bg-gray-50 text-darkgray px-8 py-4 rounded-lg font-semibold text-lg border border-gray-300 transition-colors w-full sm:w-auto"
            >
              <BookOpen className="mr-2 h-5 w-5" />
              View Documentation
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
