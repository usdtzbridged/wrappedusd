import { Shield, FileCheck, Users, TrendingUp } from "lucide-react";

export default function SecurityFeatures() {
  const features = [
    {
      icon: Shield,
      title: "Guardian Network",
      description: "Secured by 19 of the world's top validator companies running full nodes across all supported blockchains.",
      color: "text-green-600",
      bgColor: "bg-green-100"
    },
    {
      icon: FileCheck,
      title: "Multi-Signature Validation",
      description: "Requires 13 out of 19 Guardian signatures for transaction validation, ensuring maximum security.",
      color: "text-blue-600",
      bgColor: "bg-blue-100"
    },
    {
      icon: Users,
      title: "Smart Contract Verification",
      description: "All smart contracts are verified and audited, with message format and signature verification.",
      color: "text-purple-600",
      bgColor: "bg-purple-100"
    }
  ];

  const stats = [
    { label: "Guardian Nodes", value: "19" },
    { label: "Required Signatures", value: "13/19" },
    { label: "Supported Chains", value: "40+" },
    { label: "Total Volume", value: "$50B+" }
  ];

  return (
    <section id="security" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-darkgray mb-4">Security & Trust</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Wormhole is secured by a network of 19 Guardian nodes from world-class validator companies.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            {features.map((feature, index) => (
              <div key={index} className="flex items-start space-x-4">
                <div className={`w-12 h-12 ${feature.bgColor} rounded-full flex items-center justify-center flex-shrink-0`}>
                  <feature.icon className={`h-6 w-6 ${feature.color}`} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-darkgray mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-darkgray mb-6 text-center">Security Stats</h3>
            <div className="space-y-4">
              {stats.map((stat, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-gray-600">{stat.label}</span>
                  <span className="text-2xl font-bold text-darkgray">{stat.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
