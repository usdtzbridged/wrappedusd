import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <nav className="bg-white/80 backdrop-blur-md fixed w-full top-0 z-50 border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center shadow-lg">
                <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                </svg>
              </div>
              <span className="font-bold text-xl text-darkgray">wUSDT</span>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => scrollToSection('overview')}
              className="text-gray-600 hover:text-primary transition-colors"
            >
              Overview
            </button>
            <button 
              onClick={() => scrollToSection('chains')}
              className="text-gray-600 hover:text-primary transition-colors"
            >
              Chains
            </button>
            <button 
              onClick={() => scrollToSection('bridge')}
              className="text-gray-600 hover:text-primary transition-colors"
            >
              Bridge
            </button>
            <button 
              onClick={() => scrollToSection('security')}
              className="text-gray-600 hover:text-primary transition-colors"
            >
              Security
            </button>
            <button 
              onClick={() => scrollToSection('team')}
              className="text-gray-600 hover:text-primary transition-colors"
            >
              Team
            </button>
            <button 
              onClick={() => scrollToSection('docs')}
              className="text-gray-600 hover:text-primary transition-colors"
            >
              Docs
            </button>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button className="bg-primary hover:bg-secondary text-white px-6 py-2 rounded-lg font-medium transition-colors shadow-lg">
              Trade Now
            </Button>
            <button 
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
        
        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-200 py-4">
            <div className="flex flex-col space-y-4">
              <button 
                onClick={() => scrollToSection('overview')}
                className="text-gray-600 hover:text-primary transition-colors text-left"
              >
                Overview
              </button>
              <button 
                onClick={() => scrollToSection('chains')}
                className="text-gray-600 hover:text-primary transition-colors text-left"
              >
                Chains
              </button>
              <button 
                onClick={() => scrollToSection('bridge')}
                className="text-gray-600 hover:text-primary transition-colors text-left"
              >
                Bridge
              </button>
              <button 
                onClick={() => scrollToSection('security')}
                className="text-gray-600 hover:text-primary transition-colors text-left"
              >
                Security
              </button>
              <button 
                onClick={() => scrollToSection('team')}
                className="text-gray-600 hover:text-primary transition-colors text-left"
              >
                Team
              </button>
              <button 
                onClick={() => scrollToSection('docs')}
                className="text-gray-600 hover:text-primary transition-colors text-left"
              >
                Docs
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
