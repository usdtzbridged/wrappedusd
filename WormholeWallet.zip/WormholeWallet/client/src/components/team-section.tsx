import { Users, Shield, Megaphone, Mail, Globe } from "lucide-react";

export default function TeamSection() {
  const teamMembers = [
    {
      name: "Eric",
      role: "Token Manager",
      description: "Responsible for token economics and technical operations",
      icon: Shield,
      color: "from-emerald-500 to-emerald-700",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
      email: "ericwillines@gmail.com",
      website: "ericwillines.wrappedusdt.carrd.co"
    },
    {
      name: "Lumi",
      role: "Social Media Manager", 
      description: "Responsible for community management and social media strategies",
      icon: Users,
      color: "from-green-500 to-green-700",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b469?w=150&h=150&fit=crop&crop=face",
      email: "lumi.social@wrappedusdt.com",
      website: "lumi.wrappedusdt.carrd.co"
    },
    {
      name: "Erol",
      role: "Sponsor & Marketing Manager",
      description: "Responsible for marketing strategies and sponsor partnerships",
      icon: Megaphone,
      color: "from-teal-500 to-teal-700",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
      email: "erol.marketing@wrappedusdt.com",
      website: "erol.wrappedusdt.carrd.co"
    }
  ];

  return (
    <section id="team" className="py-16 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-darkgray mb-4">Our Team</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Meet our experienced team members who manage the wUSDT project
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {teamMembers.map((member, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-xl overflow-hidden hover:transform hover:scale-105 transition-all duration-300">
              <div className={`h-32 bg-gradient-to-br ${member.color} flex items-center justify-center relative`}>
                <member.icon className="h-12 w-12 text-white" />
              </div>
              
              <div className="p-6 text-center">
                {/* Avatar */}
                <div className="relative -mt-16 mb-4">
                  <div className="w-20 h-20 mx-auto rounded-full border-4 border-white shadow-lg overflow-hidden">
                    <img 
                      src={member.avatar} 
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
                
                <h3 className="text-xl font-bold text-darkgray mb-2">{member.name}</h3>
                <h4 className="text-primary font-semibold mb-3">{member.role}</h4>
                <p className="text-gray-600 leading-relaxed mb-4">{member.description}</p>
                
                {/* Contact Information */}
                {(member.email || member.website) && (
                  <div className="border-t pt-4 space-y-2">
                    {member.email && (
                      <div className="flex items-center justify-center space-x-2 text-sm text-gray-600">
                        <Mail className="h-4 w-4" />
                        <a 
                          href={`mailto:${member.email}`}
                          className="hover:text-primary transition-colors"
                        >
                          {member.email}
                        </a>
                      </div>
                    )}
                    {member.website && (
                      <div className="flex items-center justify-center space-x-2 text-sm text-gray-600">
                        <Globe className="h-4 w-4" />
                        <a 
                          href={`https://${member.website}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-primary transition-colors"
                        >
                          {member.website}
                        </a>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <div className="bg-white rounded-lg shadow-lg p-6 max-w-2xl mx-auto">
            <h3 className="text-xl font-semibold text-darkgray mb-3">Get In Touch</h3>
            <p className="text-gray-600">
              Don't hesitate to contact our team with your questions. 
              We are always ready to help our community members.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}