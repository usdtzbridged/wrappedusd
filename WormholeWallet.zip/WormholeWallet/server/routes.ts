import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Token data endpoints
  app.get("/api/token", async (req, res) => {
    try {
      const tokenData = await storage.getTokenData();
      if (!tokenData) {
        return res.status(404).json({ error: "Token data not found" });
      }
      res.json(tokenData);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch token data" });
    }
  });

  // Live price data from GeckoTerminal API
  app.get("/api/token/price", async (req, res) => {
    try {
      const response = await fetch('https://api.geckoterminal.com/api/v2/networks/solana/pools/HrU5mBkLjuWGG7VpWyXQDQvssG7rxbVS9UHuLPwzHkWG');
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      const poolData = data.data;
      
      if (poolData && poolData.attributes) {
        const priceUsd = poolData.attributes.base_token_price_usd;
        const priceChange24h = poolData.attributes.price_change_percentage?.h24 || 0;
        const volume24h = poolData.attributes.volume_usd?.h24 || 0;
        
        // Update storage with live data
        await storage.updateTokenData({
          price: priceUsd,
          change24h: priceChange24h.toString(),
          volume24h: volume24h.toString()
        });
        
        res.json({
          price: priceUsd,
          change24h: priceChange24h,
          volume24h: volume24h,
          lastUpdated: new Date()
        });
      } else {
        res.status(500).json({ error: "Invalid response format" });
      }
    } catch (error) {
      console.error("Error fetching price data:", error);
      // Return cached data if API fails
      const tokenData = await storage.getTokenData();
      if (tokenData) {
        res.json({
          price: tokenData.price,
          change24h: tokenData.change24h,
          volume24h: tokenData.volume24h,
          lastUpdated: tokenData.lastUpdated
        });
      } else {
        res.status(500).json({ error: "Failed to fetch price data" });
      }
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
