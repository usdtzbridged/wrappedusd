import { users, tokenData, type User, type InsertUser, type TokenData, type InsertTokenData } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getTokenData(): Promise<TokenData | undefined>;
  updateTokenData(data: Partial<TokenData>): Promise<TokenData | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getTokenData(): Promise<TokenData | undefined> {
    const [token] = await db.select().from(tokenData).limit(1);
    
    // If no token data exists, create initial data
    if (!token) {
      const initialTokenData: InsertTokenData = {
        symbol: "wUSDT",
        name: "Wrapped USDT",
        price: "0.1273",
        change24h: "62.87",
        marketCap: "1280000",
        volume24h: "626",
        totalSupply: "10000000000",
        circulatingSupply: "9990000000",
        lockedTokens: "2000000000",
        holders: 121,
        image: "https://bafkreic6tov6v3chg45jkjrhodt4hoerdo26bgqbvrqh6tugyiy6krll4u.ipfs.w3s.link",
        website: "https://wrappedusdt.carrd.co/",
        twitter: "https://x.com/wrappedwusdt",
        telegram: "https://t.me/wrappedusdt",
        github: "https://github.com/wrappedusdtt",
        instagram: "https://instagram.com/wrappedusdt",
        medium: "https://medium.com/@wrappedusdt"
      };
      
      const [newToken] = await db
        .insert(tokenData)
        .values(initialTokenData)
        .returning();
      return newToken;
    }
    
    return token;
  }

  async updateTokenData(data: Partial<TokenData>): Promise<TokenData | undefined> {
    const existing = await this.getTokenData();
    if (!existing) return undefined;
    
    const [updated] = await db
      .update(tokenData)
      .set({ ...data, lastUpdated: new Date() })
      .where(eq(tokenData.id, existing.id))
      .returning();
    
    return updated;
  }
}

export const storage = new DatabaseStorage();
