import { pgTable, text, serial, integer, boolean, decimal, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const tokenData = pgTable("token_data", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  name: text("name").notNull(),
  price: decimal("price", { precision: 10, scale: 6 }).notNull(),
  change24h: decimal("change_24h", { precision: 10, scale: 6 }).notNull(),
  marketCap: decimal("market_cap", { precision: 15, scale: 2 }),
  volume24h: decimal("volume_24h", { precision: 15, scale: 2 }),
  totalSupply: decimal("total_supply", { precision: 15, scale: 2 }),
  circulatingSupply: decimal("circulating_supply", { precision: 15, scale: 2 }),
  lockedTokens: decimal("locked_tokens", { precision: 15, scale: 2 }),
  holders: integer("holders"),
  image: text("image"),
  website: text("website"),
  twitter: text("twitter"),
  telegram: text("telegram"),
  github: text("github"),
  instagram: text("instagram"),
  medium: text("medium"),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const chainData = pgTable("chain_data", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  symbol: text("symbol").notNull(),
  contractAddress: text("contract_address").notNull(),
  explorerUrl: text("explorer_url").notNull(),
  iconClass: text("icon_class").notNull(),
  colorClass: text("color_class").notNull(),
  description: text("description").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertTokenDataSchema = createInsertSchema(tokenData).omit({
  id: true,
  lastUpdated: true,
});

export const insertChainDataSchema = createInsertSchema(chainData).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type TokenData = typeof tokenData.$inferSelect;
export type ChainData = typeof chainData.$inferSelect;
export type InsertTokenData = z.infer<typeof insertTokenDataSchema>;
export type InsertChainData = z.infer<typeof insertChainDataSchema>;
