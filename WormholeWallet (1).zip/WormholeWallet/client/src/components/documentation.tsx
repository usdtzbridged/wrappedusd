import { BookOpen, Code, Users, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Documentation() {
  const resources = [
    {
      icon: BookOpen,
      title: "Getting Started",
      description: "Learn how to use Wrapped USDT for cross-chain transfers and DeFi applications.",
      color: "text-blue-600",
      bgColor: "bg-blue-100",
      link: "#"
    },
    {
      icon: Code,
      title: "Developer API",
      description: "Integrate Wormhole bridge functionality into your applications with our SDK.",
      color: "text-green-600",
      bgColor: "bg-green-100",
      link: "#"
    },
    {
      icon: Users,
      title: "Community",
      description: "Join our community for support, updates, and discussions about Wrapped USDT.",
      color: "text-purple-600",
      bgColor: "bg-purple-100",
      link: "#"
    }
  ];

  return (
    <section id="docs" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-darkgray mb-4">Documentation & Resources</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Get started with comprehensive guides and developer resources for Wrapped USDT integration.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {resources.map((resource, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
              <div className={`w-12 h-12 ${resource.bgColor} rounded-full flex items-center justify-center mb-4`}>
                <resource.icon className={`h-6 w-6 ${resource.color}`} />
              </div>
              <h3 className="text-xl font-semibold text-darkgray mb-3">{resource.title}</h3>
              <p className="text-gray-600 mb-4">{resource.description}</p>
              <Button
                variant="ghost"
                className="text-primary hover:underline font-medium p-0"
                onClick={() => window.open(resource.link, '_blank')}
              >
                {resource.title === "Community" ? "Join Discord" : resource.title === "Developer API" ? "View API" : "Read Guide"}
                <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
