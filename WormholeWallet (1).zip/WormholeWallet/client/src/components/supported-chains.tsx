import { ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function SupportedChains() {
  const chains = [
    {
      name: "Solana",
      symbol: "SOL",
      description: "Primary Network",
      contractAddress: "57GajvDHazpCCCCpKgiHppJJf5cjwHWancCZZLPoeFMj",
      explorerUrl: "https://solscan.io/token/57GajvDHazpCCCCpKgiHppJJf5cjwHWancCZZLPoeFMj",
      explorerName: "Solscan",
      icon: "fas fa-circle",
      color: "text-purple-600",
      bgColor: "bg-purple-100"
    },
    {
      name: "GeckoTerminal",
      symbol: "GECKO",
      description: "Trading Pool",
      contractAddress: "HrU5mBkLjuWGG7VpWyXQDQvssG7rxbVS9UHuLPwzHkWG",
      explorerUrl: "https://www.geckoterminal.com/tr/solana/pools/HrU5mBkLjuWGG7VpWyXQDQvssG7rxbVS9UHuLPwzHkWG",
      explorerName: "GeckoTerminal",
      icon: "fas fa-chart-line",
      color: "text-green-600",
      bgColor: "bg-green-100"
    },
    {
      name: "Jupiter",
      symbol: "JUP",
      description: "Token Lock",
      contractAddress: "Jupiter Lock Program",
      explorerUrl: "https://lock.jup.ag/created",
      explorerName: "Jupiter Lock",
      icon: "fas fa-lock",
      color: "text-blue-600",
      bgColor: "bg-blue-100"
    },
    {
      name: "Metadata",
      symbol: "META",
      description: "Token Info",
      contractAddress: "IPFS Token Metadata",
      explorerUrl: "https://bafkreic6tov6v3chg45jkjrhodt4hoerdo26bgqbvrqh6tugyiy6krll4u.ipfs.w3s.link",
      explorerName: "IPFS",
      icon: "fas fa-database",
      color: "text-orange-600",
      bgColor: "bg-orange-100"
    }
  ];

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <section id="chains" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-darkgray mb-4">Network Information</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            wUSDT token information and trading resources on the Solana blockchain network.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {chains.map((chain, index) => (
            <div key={index} className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="flex items-center space-x-4 mb-4">
                <div className={`w-12 h-12 ${chain.bgColor} rounded-full flex items-center justify-center`}>
                  <i className={`${chain.icon} ${chain.color} text-xl`}></i>
                </div>
                <div>
                  <h3 className="font-semibold text-darkgray">{chain.name}</h3>
                  <div className="text-sm text-gray-500">{chain.description}</div>
                </div>
              </div>
              <div className="space-y-2">
                <div className="text-xs text-gray-500">Contract Address:</div>
                <div 
                  className="text-xs font-mono bg-gray-100 p-2 rounded cursor-pointer hover:bg-gray-200 transition-colors"
                  onClick={() => copyToClipboard(chain.contractAddress)}
                  title="Click to copy"
                >
                  {chain.contractAddress}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-primary text-sm hover:underline p-0"
                  onClick={() => window.open(chain.explorerUrl, '_blank')}
                >
                  <ExternalLink className="h-3 w-3 mr-1" />
                  View on {chain.explorerName}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
