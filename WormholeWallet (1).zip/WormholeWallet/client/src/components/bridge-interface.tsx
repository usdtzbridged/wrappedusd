import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ExternalLink, TrendingUp, Volume2, Users } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

export default function BridgeInterface() {
  const { data: priceData } = useQuery({
    queryKey: ['/api/token/price'],
    refetchInterval: 30000,
  });

  const { data: tokenData } = useQuery({
    queryKey: ['/api/token'],
  });

  const formatPrice = (price: string | number) => {
    const numPrice = typeof price === 'string' ? parseFloat(price) : price;
    return numPrice ? `$${numPrice.toFixed(4)}` : '$0.0000';
  };

  const formatVolume = (volume: string | number) => {
    const numVolume = typeof volume === 'string' ? parseFloat(volume) : volume;
    return numVolume ? `$${numVolume.toFixed(2)}` : '$0.00';
  };

  const formatNumber = (num: string | number) => {
    const numVal = typeof num === 'string' ? parseFloat(num) : num;
    if (numVal >= 1000000000) {
      return `${(numVal / 1000000000).toFixed(1)}B`;
    } else if (numVal >= 1000000) {
      return `${(numVal / 1000000).toFixed(1)}M`;
    }
    return numVal.toString();
  };

  return (
    <section id="bridge" className="py-16 bg-gradient-bridge">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-darkgray mb-4">Token Trading</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Trade wUSDT tokens on Solana with live market data and direct access to trading platforms.
          </p>
        </div>
        
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          <div className="space-y-6">
            {/* Token Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gradient-to-r from-green-50 to-emerald-100 rounded-xl p-6">
                <div className="flex items-center space-x-3 mb-3">
                  <TrendingUp className="h-6 w-6 text-primary" />
                  <h3 className="text-lg font-semibold text-darkgray">Current Price</h3>
                </div>
                <div className="text-2xl font-bold text-darkgray mb-1">
                  {formatPrice(priceData?.price || '0.1273')}
                </div>
                <div className={`text-sm ${
                  priceData?.change24h && parseFloat(priceData.change24h) >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {priceData?.change24h && parseFloat(priceData.change24h) >= 0 ? '+' : ''}{priceData?.change24h || '62.87'}% 24h
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-green-50 to-emerald-100 rounded-xl p-6">
                <div className="flex items-center space-x-3 mb-3">
                  <Volume2 className="h-6 w-6 text-secondary" />
                  <h3 className="text-lg font-semibold text-darkgray">24h Volume</h3>
                </div>
                <div className="text-2xl font-bold text-darkgray">
                  {formatVolume(priceData?.volume24h || '626')}
                </div>
                <div className="text-sm text-gray-600">Trading volume</div>
              </div>
            </div>
            
            {/* Token Statistics */}
            <div className="bg-gray-50 rounded-lg p-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-lg font-bold text-darkgray">{formatNumber(tokenData?.totalSupply || '10000000000')}</div>
                  <div className="text-sm text-gray-600">Total Supply</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-darkgray">{formatNumber(tokenData?.circulatingSupply || '9990000000')}</div>
                  <div className="text-sm text-gray-600">Circulating</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-darkgray">{formatNumber(tokenData?.lockedTokens || '2000000000')}</div>
                  <div className="text-sm text-gray-600">Locked</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-darkgray">{tokenData?.holders || 121}</div>
                  <div className="text-sm text-gray-600">Holders</div>
                </div>
              </div>
            </div>
            
            {/* Trading Links */}
            <div className="space-y-4">
              <Button 
                className="w-full bg-primary hover:bg-secondary text-white py-4 rounded-lg font-semibold text-lg shadow-lg"
                onClick={() => window.open('https://www.geckoterminal.com/tr/solana/pools/HrU5mBkLjuWGG7VpWyXQDQvssG7rxbVS9UHuLPwzHkWG', '_blank')}
              >
                <ExternalLink className="mr-2 h-5 w-5" />
                Trade on GeckoTerminal
              </Button>
              
              <Button 
                variant="outline"
                className="w-full bg-white hover:bg-green-50 text-darkgray py-4 rounded-lg font-semibold text-lg border-2 border-primary hover:border-secondary"
                onClick={() => window.open('https://solscan.io/token/57GajvDHazpCCCCpKgiHppJJf5cjwHWancCZZLPoeFMj', '_blank')}
              >
                <ExternalLink className="mr-2 h-5 w-5" />
                View on Solscan
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
